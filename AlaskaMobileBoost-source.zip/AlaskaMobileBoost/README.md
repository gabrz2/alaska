# AlaskaMobileBoost 1.0.0

Mod de monitoramento leve para Minecraft Java 1.20.1 / Forge 47.4.0 / Java 17.

## O que esta versao faz
- Exibe FPS atual e menor FPS observado desde o inicio da sessao.
- Exibe heap da JVM (memoria usada/heap maximo).
- Sinaliza FPS baixo sustentado com histerese simples.
- Mede TPS aproximado no lado servidor (ainda sem painel remoto no cliente).
- Mantem codigo client-only separado por `Dist.CLIENT`.

## O que esta versao NAO faz
- Nao altera automaticamente render distance, simulation distance ou limite de FPS.
- Nao intercepta ou remove particulas de outros mods.
- Nao altera Embeddium, Oculus, Distant Horizons ou shaders.
- Nao limpa entidades/itens nem descarrega chunks.

## Compilar
Requisitos: JDK 17 e Gradle 8.1.1.

Na pasta do projeto, execute:

```bash
gradle build
```

O JAR reobfuscado deve aparecer em `build/libs/AlaskaMobileBoost-1.0.0.jar`.

## Instalar
Copie o JAR compilado para a pasta `mods` da instância Minecraft Forge 1.20.1. Não instale em Minecraft Bedrock.

## Configuração
Após a primeira inicialização, o Forge cria `config/alaskamobileboost-client.toml`.

## Compilar pelo GitHub (sem instalar Java/Gradle no celular)
1. Crie um repositório no GitHub e envie os arquivos desta pasta.
2. Abra a aba **Actions** do repositório.
3. Execute **Build AlaskaMobileBoost** usando **Run workflow** (ou aguarde o build automático após enviar para `main`).
4. Quando terminar, abra a execução e baixe o artefato `AlaskaMobileBoost-1.0.0`.
5. Dentro do ZIP do artefato estará o `.jar` compilado.

O workflow compila com Java 17 e Gradle 8.1.1. Se houver erro de compilação, a execução mostrará o log; o JAR não deve ser instalado até o build terminar com sucesso.
