package com.alaska.mobileboost.client;

import com.alaska.mobileboost.AlaskaMobileBoost;
import com.alaska.mobileboost.config.ClientConfig;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AlaskaMobileBoost.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientEvents {
    private static long lastSampleNanos;

    private ClientEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !ClientConfig.ENABLE_FPS_MONITOR.get()) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (!minecraft.isWindowActive() || minecraft.isPaused()) return;

        long now = System.nanoTime();
        if (now - lastSampleNanos < 1_000_000_000L) return;
        lastSampleNanos = now;
        ClientMetrics.sample(minecraft.getFps(), ClientConfig.TARGET_MIN_FPS.get(), ClientConfig.LOW_FPS_SECONDS.get());
    }
}
