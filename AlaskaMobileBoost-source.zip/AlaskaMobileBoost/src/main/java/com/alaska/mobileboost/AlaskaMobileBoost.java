package com.alaska.mobileboost;

import com.alaska.mobileboost.config.ClientConfig;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(AlaskaMobileBoost.MOD_ID)
public final class AlaskaMobileBoost {
    public static final String MOD_ID = "alaskamobileboost";

    public AlaskaMobileBoost() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
    }
}
