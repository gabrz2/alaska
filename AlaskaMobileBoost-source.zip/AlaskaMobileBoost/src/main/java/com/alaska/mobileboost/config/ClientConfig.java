package com.alaska.mobileboost.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class ClientConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLE_OVERLAY;
    public static final ForgeConfigSpec.BooleanValue ENABLE_FPS_MONITOR;
    public static final ForgeConfigSpec.IntValue TARGET_MIN_FPS;
    public static final ForgeConfigSpec.IntValue LOW_FPS_SECONDS;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("client");
        ENABLE_OVERLAY = builder
                .comment("Mostra o painel de desempenho no jogo.")
                .define("enableOverlay", true);
        ENABLE_FPS_MONITOR = builder
                .comment("Ativa o monitoramento de FPS.")
                .define("enableFpsMonitor", true);
        TARGET_MIN_FPS = builder
                .comment("Limite usado para sinalizar FPS baixo; nao altera graficos automaticamente.")
                .defineInRange("targetMinFps", 25, 10, 120);
        LOW_FPS_SECONDS = builder
                .comment("Tempo de FPS baixo antes de exibir o alerta.")
                .defineInRange("lowFpsSeconds", 5, 2, 60);
        builder.pop();
        SPEC = builder.build();
    }

    private ClientConfig() {}
}
