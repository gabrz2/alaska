package com.alaska.mobileboost.server;

import com.alaska.mobileboost.AlaskaMobileBoost;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AlaskaMobileBoost.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ServerPerformanceMonitor {
    private static long windowStartNanos;
    private static int ticksInWindow;
    private static volatile double estimatedTps = 20.0;

    private ServerPerformanceMonitor() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (windowStartNanos == 0L) windowStartNanos = System.nanoTime();
        ticksInWindow++;
        if (ticksInWindow >= 20) {
            long elapsed = System.nanoTime() - windowStartNanos;
            if (elapsed > 0L) {
                estimatedTps = Math.min(20.0, 20.0 * 1_000_000_000.0 / elapsed);
            }
            ticksInWindow = 0;
            windowStartNanos = System.nanoTime();
        }
    }

    public static double getEstimatedTps() {
        return estimatedTps;
    }
}
