package com.alaska.mobileboost.client;

public final class ClientMetrics {
    private static int fps;
    private static int minimumFps = Integer.MAX_VALUE;
    private static long lowFpsSinceNanos;
    private static boolean lowFpsWarning;

    private ClientMetrics() {}

    public static void sample(int currentFps, int targetFps, int lowFpsSeconds) {
        fps = Math.max(0, currentFps);
        if (fps > 0) {
            minimumFps = Math.min(minimumFps, fps);
        }

        long now = System.nanoTime();
        if (fps > 0 && fps < targetFps) {
            if (lowFpsSinceNanos == 0L) {
                lowFpsSinceNanos = now;
            }
            lowFpsWarning = now - lowFpsSinceNanos >= lowFpsSeconds * 1_000_000_000L;
        } else if (fps >= targetFps + 5) {
            lowFpsSinceNanos = 0L;
            lowFpsWarning = false;
        }
    }

    public static int getFps() { return fps; }
    public static int getMinimumFps() { return minimumFps == Integer.MAX_VALUE ? 0 : minimumFps; }
    public static boolean isLowFpsWarning() { return lowFpsWarning; }
}
