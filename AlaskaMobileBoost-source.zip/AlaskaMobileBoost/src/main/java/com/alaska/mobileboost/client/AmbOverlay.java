package com.alaska.mobileboost.client;

import com.alaska.mobileboost.AlaskaMobileBoost;
import com.alaska.mobileboost.config.ClientConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;

@Mod.EventBusSubscriber(modid = AlaskaMobileBoost.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AmbOverlay {
    private AmbOverlay() {}

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        if (!ClientConfig.ENABLE_OVERLAY.get()) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) return;

        Runtime runtime = Runtime.getRuntime();
        long usedMb = (runtime.totalMemory() - runtime.freeMemory()) / 1_048_576L;
        long maxMb = runtime.maxMemory() / 1_048_576L;
        double heapPercent = maxMb > 0 ? usedMb * 100.0 / maxMb : 0.0;

        int x = 8;
        int y = 8;
        int width = 154;
        int height = 77;
        GuiGraphics graphics = event.getGuiGraphics();
        graphics.fill(x, y, x + width, y + height, 0x99000000);
        draw(graphics, minecraft, "ALASKA MOBILE BOOST", x + 5, y + 5, 0x55FFAA);
        draw(graphics, minecraft, "FPS: " + ClientMetrics.getFps() + "  MIN: " + ClientMetrics.getMinimumFps(), x + 5, y + 19, 0xFFFFFF);
        draw(graphics, minecraft, String.format(Locale.ROOT, "RAM: %d/%d MB", usedMb, maxMb), x + 5, y + 32, 0xFFFFFF);
        draw(graphics, minecraft, String.format(Locale.ROOT, "HEAP: %.1f%%", heapPercent), x + 5, y + 45, 0xFFFFFF);
        String status = ClientMetrics.isLowFpsWarning() ? "FPS BAIXO" : "ESTAVEL";
        int color = ClientMetrics.isLowFpsWarning() ? 0xFFAA55 : 0x55FFAA;
        draw(graphics, minecraft, "STATUS: " + status, x + 5, y + 58, color);
    }

    private static void draw(GuiGraphics graphics, Minecraft minecraft, String text, int x, int y, int color) {
        graphics.drawString(minecraft.font, Component.literal(text), x, y, color, false);
    }
}
